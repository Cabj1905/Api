package administracion.tpo.repository;

import administracion.tpo.modelo.Unidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositoryUnidad extends JpaRepository<Unidad,Integer> {

}
